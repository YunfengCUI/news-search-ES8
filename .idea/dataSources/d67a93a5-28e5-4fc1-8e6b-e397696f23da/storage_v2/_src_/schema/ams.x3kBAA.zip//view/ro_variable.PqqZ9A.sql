create view ro_variable as
select `roeee`.`ro_variable`.`VUUID`      AS `VUUID`,
       `roeee`.`ro_variable`.`VNAME`      AS `VNAME`,
       `roeee`.`ro_variable`.`VVALUE`     AS `VVALUE`,
       `roeee`.`ro_variable`.`VTYPE`      AS `VTYPE`,
       `roeee`.`ro_variable`.`VREMARK`    AS `VREMARK`,
       `roeee`.`ro_variable`.`CREATEUSER` AS `CREATEUSER`,
       `roeee`.`ro_variable`.`CREATETIME` AS `CREATETIME`,
       `roeee`.`ro_variable`.`UPDATEUSER` AS `UPDATEUSER`,
       `roeee`.`ro_variable`.`UPDATETIME` AS `UPDATETIME`
from `roeee`.`ro_variable`;

