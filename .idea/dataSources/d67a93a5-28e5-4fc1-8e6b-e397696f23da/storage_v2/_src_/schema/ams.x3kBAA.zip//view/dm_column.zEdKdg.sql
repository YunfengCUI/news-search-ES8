create view dm_column as
select `ams`.`dt_col_meta`.`COL_META_UUID`   AS `DM_COLUMN_UUID`,
       `ams`.`dt_col_meta`.`TABLE_META_UUID` AS `DM_TABLE_UUID`,
       `ams`.`dt_col_meta`.`COL_NAME`        AS `COLUMN_NAME`,
       `ams`.`dt_col_meta`.`CHN_NAME`        AS `ALIAS`,
       `ams`.`dt_col_meta`.`datatype`        AS `COLUMN_TYPE`,
       `ams`.`dt_col_meta`.`CHN_NAME`        AS `CN_NAME`,
       `ams`.`dt_col_meta`.`COL_COMMENT`     AS `COMMENT`,
       1                                     AS `TYPE`
from `ams`.`dt_col_meta`
union all
select `ams`.`in_calculation_column`.`IN_CALCULATION_COLUMN_UUID` AS `DM_COLUMN_UUID`,
       `ams`.`in_calculation_column`.`CALCULATION_COLUMN_TABLEID` AS `DM_TABLE_UUID`,
       `ams`.`in_calculation_column`.`CALCULATION_COLUMN_NAME`    AS `CALCULATION_COLUMN_NAME`,
       `ams`.`in_calculation_column`.`CALCULATION_COLUMN_NAME`    AS `ALIAS`,
       'VARCHAR'                                                  AS `COLUMN_TYPE`,
       `ams`.`in_calculation_column`.`CALCULATION_COLUMN_NAME`    AS `CN_NAME`,
       '无'                                                        AS `COMMENT`,
       2                                                          AS `TYPE`
from `ams`.`in_calculation_column`;

