create view sys_orgperson as
select `sys_orgperson`.`PERSONUUID` AS `PERSONUUID`,
       `sys_orgperson`.`ORGUUID`    AS `ORGUUID`,
       `sys_orgperson`.`ISBELONG`   AS `ISBELONG`
from `roeee`.`sys_orgperson`;

