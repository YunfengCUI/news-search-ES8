create view v_folder_vr as
select '0000000000000000000000000000000000000000000000000000000000000000' AS `folder_uuid`,
       'ORG_FOLDER'                                                       AS `folder_code`,
       '机构数据'                                                             AS `folder_name`,
       'ROOT'                                                             AS `PARENT_FOLDER_UUID`,
       0                                                                  AS `ORDER_NUM`,
       ''                                                                 AS `FULL_PATH`,
       ''                                                                 AS `CREATE_USER_UUID`,
       ''                                                                 AS `CREATE_USER_NAME`,
       ''                                                                 AS `SCENE_INST_UUID`,
       NULL                                                               AS `CREATE_TIME`
union
select `a`.`ORGUUID`       AS `folder_uuid`,
       `a`.`ORGCODE`       AS `folder_code`,
       `a`.`CNNAME`        AS `folder_name`,
       `a`.`PARENTORGUUID` AS `PARENT_FOLDER_UUID`,
       `a`.`SEQUENCENO`    AS `ORDER_NUM`,
       ''                  AS `FULL_PATH`,
       ''                  AS `CREATE_USER_UUID`,
       ''                  AS `CREATE_USER_NAME`,
       ''                  AS `SCENE_INST_UUID`,
       NULL                AS `CREATE_TIME`
from `ams`.`sys_org` `a`
where ((`a`.`DELTAG` = 0) and (`a`.`STATUS` <> 1));

