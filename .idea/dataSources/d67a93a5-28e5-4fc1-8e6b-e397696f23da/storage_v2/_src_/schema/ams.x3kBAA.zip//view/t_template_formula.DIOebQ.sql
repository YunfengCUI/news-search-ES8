create view t_template_formula as
select `ams`.`aa_model`.`MODEL_UUID`       AS `PARAMETER_ID`,
       `ams`.`aa_model`.`MODEL_NAME`       AS `PARAMETER_CODE`,
       `ams`.`aa_model`.`MODEL_NAME`       AS `PARAMETER_NAME`,
       '文本类型'                              AS `PARAMETER_TYPE_NAME`,
       '0001'                              AS `PARAMETER_TYPE_CODE`,
       ''                                  AS `DESCRIBEINFO`,
       `ams`.`aa_model`.`SQL_VALUE`        AS `SQL_LANGUAGE`,
       `ams`.`aa_model`.`CREATE_USER_UUID` AS `CREATE_USER_UUID`,
       `ams`.`aa_model`.`CREATE_USER_NAME` AS `CREATE_USER_NAME`,
       `ams`.`aa_model`.`CREATE_TIME`      AS `CREATE_TIME`,
       `ams`.`aa_model`.`UPDATE_USER_UUID` AS `UPDATE_USER_UUID`,
       `ams`.`aa_model`.`UPDATE_USER_NAME` AS `UPDATE_USER_NAME`,
       `ams`.`aa_model`.`UPDATE_TIME`      AS `UPDATE_TIME`,
       '0'                                 AS `DEL_TAG`,
       '{"parameterTextType":"onlyValue"}' AS `PARAMETER_JSON`,
       '1'                                 AS `PARAMETER_KIND`,
       ''                                  AS `PARAMETER_SORT`,
       ''                                  AS `REL_PARAMETERS`
from `ams`.`aa_model`
where (`ams`.`aa_model`.`MODEL_USE` = '2')
union
select `robot`.`t_template_formula`.`PARAMETER_ID`        AS `PARAMETER_ID`,
       `robot`.`t_template_formula`.`PARAMETER_CODE`      AS `PARAMETER_CODE`,
       `robot`.`t_template_formula`.`PARAMETER_NAME`      AS `PARAMETER_NAME`,
       `robot`.`t_template_formula`.`PARAMETER_TYPE_NAME` AS `PARAMETER_TYPE_NAME`,
       `robot`.`t_template_formula`.`PARAMETER_TYPE_CODE` AS `PARAMETER_TYPE_CODE`,
       `robot`.`t_template_formula`.`DESCRIBEINFO`        AS `DESCRIBEINFO`,
       `robot`.`t_template_formula`.`SQL_LANGUAGE`        AS `SQL_LANGUAGE`,
       `robot`.`t_template_formula`.`CREATE_USER_UUID`    AS `CREATE_USER_UUID`,
       `robot`.`t_template_formula`.`CREATE_USER_NAME`    AS `CREATE_USER_NAME`,
       `robot`.`t_template_formula`.`CREATE_TIME`         AS `CREATE_TIME`,
       `robot`.`t_template_formula`.`UPDATE_USER_UUID`    AS `UPDATE_USER_UUID`,
       `robot`.`t_template_formula`.`UPDATE_USER_NAME`    AS `UPDATE_USER_NAME`,
       `robot`.`t_template_formula`.`UPDATE_TIME`         AS `UPDATE_TIME`,
       `robot`.`t_template_formula`.`DEL_TAG`             AS `DEL_TAG`,
       `robot`.`t_template_formula`.`PARAMETER_JSON`      AS `PARAMETER_JSON`,
       `robot`.`t_template_formula`.`PARAMETER_KIND`      AS `PARAMETER_KIND`,
       `robot`.`t_template_formula`.`PARAMETER_SORT`      AS `PARAMETER_SORT`,
       `robot`.`t_template_formula`.`REL_PARAMETERS`      AS `REL_PARAMETERS`
from `robot`.`t_template_formula`;

