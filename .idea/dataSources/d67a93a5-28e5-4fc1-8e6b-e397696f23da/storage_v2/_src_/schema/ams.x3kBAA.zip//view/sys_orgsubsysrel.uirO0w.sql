create view sys_orgsubsysrel as
select `sys_orgsubsysrel`.`SYSID`   AS `SYSID`,
       `sys_orgsubsysrel`.`ORGUUID` AS `ORGUUID`,
       `sys_orgsubsysrel`.`CNNAME`  AS `CNNAME`,
       `sys_orgsubsysrel`.`SYSNAME` AS `SYSNAME`,
       `sys_orgsubsysrel`.`SYSPROP` AS `SYSPROP`
from `roeee`.`sys_orgsubsysrel`;

