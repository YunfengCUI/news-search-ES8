create view sys_orgpersonall as
select `sys_orgpersonall`.`FULL_NAME`  AS `FULL_NAME`,
       `sys_orgpersonall`.`PERSONUUID` AS `PERSONUUID`,
       `sys_orgpersonall`.`SEX`        AS `SEX`,
       `sys_orgpersonall`.`ORGUUID`    AS `ORGUUID`,
       `sys_orgpersonall`.`CNNAME`     AS `CNNAME`
from `roeee`.`sys_orgpersonall`;

