create view v_ro_org as
select `roeee`.`ro_org`.`ORGUUID`       AS `ORGUUID`,
       `roeee`.`ro_org`.`CNNAME`        AS `CNNAME`,
       `roeee`.`ro_org`.`ORGCODE`       AS `ORGCODE`,
       `roeee`.`ro_org`.`ENNAME`        AS `ENNAME`,
       `roeee`.`ro_org`.`CONTACT`       AS `CONTACT`,
       `roeee`.`ro_org`.`ORGGRADE`      AS `ORGGRADE`,
       `roeee`.`ro_org`.`ORGPROP`       AS `ORGPROP`,
       `roeee`.`ro_org`.`ORGLEVEL`      AS `ORGLEVEL`,
       `roeee`.`ro_org`.`SERIALINDEX`   AS `SERIALINDEX`,
       `roeee`.`ro_org`.`MEMO`          AS `MEMO`,
       `roeee`.`ro_org`.`PARENTORGUUID` AS `PARENTORGUUID`,
       `roeee`.`ro_org`.`STATUS`        AS `STATUS`,
       `roeee`.`ro_org`.`ORGLEVELCODE`  AS `ORGLEVELCODE`,
       `roeee`.`ro_org`.`SEQUENCENO`    AS `SEQUENCENO`,
       `roeee`.`ro_org`.`DELTAG`        AS `DELTAG`,
       `roeee`.`ro_org`.`EXTEND1`       AS `EXTEND1`,
       `roeee`.`ro_org`.`EXTEND2`       AS `EXTEND2`,
       `roeee`.`ro_org`.`EXTEND3`       AS `EXTEND3`,
       `roeee`.`ro_org`.`CREATETIME`    AS `CREATETIME`,
       `roeee`.`ro_org`.`CREATEUSER`    AS `CREATEUSER`,
       `roeee`.`ro_org`.`UPDATEUSER`    AS `UPDATEUSER`,
       `roeee`.`ro_org`.`UPDATETIME`    AS `UPDATETIME`
from `roeee`.`ro_org`
where (`roeee`.`ro_org`.`DELTAG` = '0');

