create view v_sys_role as
select `sys_role`.`ROLEID`     AS `ROLEID`,
       `sys_role`.`SYSID`      AS `SYSID`,
       `sys_role`.`CNNAME`     AS `CNNAME`,
       `sys_role`.`ROLEDESC`   AS `ROLEDESC`,
       `sys_role`.`STATUS`     AS `STATUS`,
       `sys_role`.`CREATETIME` AS `CREATETIME`,
       `sys_role`.`SEQUENCENO` AS `SEQUENCENO`,
       `sys_role`.`CREATEBY`   AS `CREATEBY`,
       `sys_role`.`ROLECODE`   AS `ROLECODE`,
       `sys_role`.`SYSNAME`    AS `SYSNAME`
from `roeee`.`sys_role`
where ((`sys_role`.`STATUS` = '0') and (`sys_role`.`SYSID` = 2));

