create view sys_system as
select `sys_system`.`SYSID`        AS `SYSID`,
       `sys_system`.`SYSNAME`      AS `SYSNAME`,
       `sys_system`.`SYSPROP`      AS `SYSPROP`,
       `sys_system`.`SEQUENCENO`   AS `SEQUENCENO`,
       `sys_system`.`PARENTSYSID`  AS `PARENTSYSID`,
       `sys_system`.`SYSLEVELCODE` AS `SYSLEVELCODE`
from `roeee`.`sys_system`;

