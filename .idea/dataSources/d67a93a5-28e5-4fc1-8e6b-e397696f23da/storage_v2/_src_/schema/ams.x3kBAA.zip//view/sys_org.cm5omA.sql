create view sys_org as
select `sys_org`.`ORGUUID`       AS `ORGUUID`,
       `sys_org`.`CNNAME`        AS `CNNAME`,
       `sys_org`.`ENNAME`        AS `ENNAME`,
       `sys_org`.`ORGCODE`       AS `ORGCODE`,
       `sys_org`.`CONTACT`       AS `CONTACT`,
       `sys_org`.`ORGGRADE`      AS `ORGGRADE`,
       `sys_org`.`ORGPROP`       AS `ORGPROP`,
       `sys_org`.`ORGLEVEL`      AS `ORGLEVEL`,
       `sys_org`.`SERIALINDEX`   AS `SERIALINDEX`,
       `sys_org`.`MEMO`          AS `MEMO`,
       `sys_org`.`PARENTORGUUID` AS `PARENTORGUUID`,
       `sys_org`.`STATUS`        AS `STATUS`,
       `sys_org`.`ORGLEVELCODE`  AS `ORGLEVELCODE`,
       `sys_org`.`DELTAG`        AS `DELTAG`,
       `sys_org`.`SEQUENCENO`    AS `SEQUENCENO`
from `roeee`.`sys_org`;

