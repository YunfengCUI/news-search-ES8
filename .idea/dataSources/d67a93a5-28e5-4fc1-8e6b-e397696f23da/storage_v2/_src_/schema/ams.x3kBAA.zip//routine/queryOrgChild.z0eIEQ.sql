create
    definer = root@`%` function queryOrgChild(rootId varchar(64)) returns varchar(4000)
BEGIN
    DECLARE sTemp VARCHAR(4000);
    DECLARE sTempChd VARCHAR(4000);

    SET sTemp = '';
    SET sTempChd = rootId;

    WHILE sTempChd is not NULL DO
            SET sTemp = CONCAT(sTemp,',',sTempChd);
            SELECT group_concat(ORGUUID) INTO sTempChd FROM sys_org where FIND_IN_SET(PARENTORGUUID,sTempChd)>0;
        END WHILE;
    return sTemp;
END;

