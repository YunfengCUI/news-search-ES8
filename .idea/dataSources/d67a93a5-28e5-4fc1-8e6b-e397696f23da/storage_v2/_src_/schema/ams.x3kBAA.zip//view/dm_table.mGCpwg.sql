create view dm_table as
select `ams`.`dt_table_meta`.`TABLE_META_UUID`                                   AS `DM_TABLE_UUID`,
       `ams`.`dt_table_meta`.`TB_NAME`                                           AS `TABLE_NAME`,
       ifnull(`ams`.`dt_table_meta`.`CHN_NAME`, `ams`.`dt_table_meta`.`TB_NAME`) AS `ALIAS_NAME`,
       `ams`.`dt_table_meta`.`TBL_TYPE`                                          AS `TBL_TYPE`,
       `ams`.`dt_table_meta`.`TB_COMMENT`                                        AS `COMMENT`
from `ams`.`dt_table_meta`;

