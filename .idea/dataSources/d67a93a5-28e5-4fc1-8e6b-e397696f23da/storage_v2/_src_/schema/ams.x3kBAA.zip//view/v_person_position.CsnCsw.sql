create view v_person_position as
select `rrp`.`PID`        AS `PID`,
       `rrp`.`PCODE`      AS `PCODE`,
       `rrp`.`ORGUUID`    AS `ORGUUID`,
       `rrp`.`PNAME`      AS `PNAME`,
       `rrp`.`REMARK`     AS `REMARK`,
       `rrp`.`CREATEUSER` AS `CREATEUSER`,
       `rrp`.`CREATETIME` AS `CREATETIME`,
       `rrp`.`UPDATEUSER` AS `UPDATEUSER`,
       `rrp`.`UPDATETIME` AS `UPDATETIME`
from `roeee`.`ro_position` `rrp`;

