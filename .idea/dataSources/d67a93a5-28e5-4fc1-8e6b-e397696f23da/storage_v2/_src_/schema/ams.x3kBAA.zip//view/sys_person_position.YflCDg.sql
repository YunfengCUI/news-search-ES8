create view sys_person_position as
select `sys_person_position`.`PCODE` AS `PCODE`, `sys_person_position`.`PERSONUUID` AS `PERSONUUID`
from `roeee`.`sys_person_position`;

