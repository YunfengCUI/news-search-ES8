create view sys_approle_person as
select `sys_approle_person`.`PERSONUUID` AS `PERSONUUID`,
       `sys_approle_person`.`PERSONNAME` AS `PERSONNAME`,
       `sys_approle_person`.`ROLENAME`   AS `ROLENAME`,
       `sys_approle_person`.`ROLECODE`   AS `ROLECODE`
from `roeee`.`sys_approle_person`;

