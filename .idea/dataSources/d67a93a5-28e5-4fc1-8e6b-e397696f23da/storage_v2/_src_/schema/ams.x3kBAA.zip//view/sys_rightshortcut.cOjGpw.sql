create view sys_rightshortcut as
select `sys_rightshortcut`.`PERSONUUID` AS `PERSONUUID`,
       `sys_rightshortcut`.`ROLEID`     AS `ROLEID`,
       `sys_rightshortcut`.`SYSID`      AS `SYSID`,
       `sys_rightshortcut`.`CNNAME`     AS `CNNAME`
from `roeee`.`sys_rightshortcut`;

