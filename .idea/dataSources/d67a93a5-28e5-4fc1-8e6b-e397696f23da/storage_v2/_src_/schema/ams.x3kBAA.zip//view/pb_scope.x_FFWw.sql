create view pb_scope as
select `roeee`.`ro_person`.`PERSONUUID` AS `PB_SCOPE_UUID`,
       '个人'                             AS `SCOPE_NAME`,
       '个人'                             AS `SCOPE_ALIAS`,
       3                                AS `SCOPE_TYPE`,
       `roeee`.`ro_person`.`PERSONUUID` AS `DATA_UUID`,
       30                               AS `ORDER_NO`
from `roeee`.`ro_person`
union
select `roeee`.`ro_org`.`ORGUUID` AS `PB_SCOPE_UUID`,
       '机构'                       AS `SCOPE_NAME`,
       '机构'                       AS `SCOPE_ALIAS`,
       2                          AS `SCOPE_TYPE`,
       `roeee`.`ro_org`.`ORGUUID` AS `DATA_UUID`,
       20                         AS `ORDER_NO`
from `roeee`.`ro_org`
where (`roeee`.`ro_org`.`ORGLEVEL` = 1)
union
select '1'  AS `PB_SCOPE_UUID`,
       '全行' AS `SCOPE_NAME`,
       '机构' AS `SCOPE_ALIAS`,
       1    AS `SCOPE_TYPE`,
       '1'  AS `DATA_UUID`,
       10   AS `ORDER_NO`
from `roeee`.`ro_org`;

