create view v_folder as
select `a`.`folder_uuid`        AS `FOLDER_UUID`,
       `a`.`folder_code`        AS `FOLDER_CODE`,
       `a`.`folder_name`        AS `FOLDER_NAME`,
       `a`.`PARENT_FOLDER_UUID` AS `PARENT_FOLDER_UUID`,
       `a`.`ORDER_NUM`          AS `ORDER_NUM`,
       `a`.`FULL_PATH`          AS `FULL_PATH`,
       `a`.`CREATE_USER_UUID`   AS `CREATE_USER_UUID`,
       `a`.`CREATE_USER_NAME`   AS `CREATE_USER_NAME`,
       `a`.`CREATE_TIME`        AS `CREATE_TIME`,
       `a`.`SCENE_INST_UUID`    AS `SCENE_INST_UUID`,
       'virtual'                AS `FOLDER_TYPE`
from `ams`.`v_folder_vr` `a`
union
select `a`.`FOLDER_UUID`        AS `FOLDER_UUID`,
       `a`.`FOLDER_CODE`        AS `FOLDER_CODE`,
       `a`.`FOLDER_NAME`        AS `FOLDER_NAME`,
       `a`.`PARENT_FOLDER_UUID` AS `PARENT_FOLDER_UUID`,
       `a`.`ORDER_NUM`          AS `ORDER_NUM`,
       `a`.`FULL_PATH`          AS `FULL_PATH`,
       `a`.`CREATE_USER_UUID`   AS `CREATE_USER_UUID`,
       `a`.`CREATE_USER_NAME`   AS `CREATE_USER_NAME`,
       `a`.`CREATE_TIME`        AS `CREATE_TIME`,
       `a`.`SCENE_INST_UUID`    AS `SCENE_INST_UUID`,
       'maintained'             AS `FOLDER_TYPE`
from `ams`.`dt_folder` `a`;

