create view ro_personaccount as
select `roeee`.`ro_personaccount`.`PERSONUUID`    AS `PERSONUUID`,
       `roeee`.`ro_personaccount`.`FLAG`          AS `FLAG`,
       `roeee`.`ro_personaccount`.`USERID`        AS `USERID`,
       `roeee`.`ro_personaccount`.`PASSWORD`      AS `PASSWORD`,
       `roeee`.`ro_personaccount`.`ACCOUNTSTAT`   AS `ACCOUNTSTAT`,
       `roeee`.`ro_personaccount`.`LOGINFAILNUM`  AS `LOGINFAILNUM`,
       `roeee`.`ro_personaccount`.`LASTLOGINIP`   AS `LASTLOGINIP`,
       `roeee`.`ro_personaccount`.`LASTLOGINDATE` AS `LASTLOGINDATE`,
       `roeee`.`ro_personaccount`.`PASSQUESTION`  AS `PASSQUESTION`,
       `roeee`.`ro_personaccount`.`PASSANSWER`    AS `PASSANSWER`,
       `roeee`.`ro_personaccount`.`TTLFLAG`       AS `TTLFLAG`,
       `roeee`.`ro_personaccount`.`ACCOUNTTTL`    AS `ACCOUNTTTL`,
       `roeee`.`ro_personaccount`.`CREATETIME`    AS `CREATETIME`,
       `roeee`.`ro_personaccount`.`DELTAG`        AS `DELTAG`,
       `roeee`.`ro_personaccount`.`CREATEUSER`    AS `CREATEUSER`,
       `roeee`.`ro_personaccount`.`UPDATEUSER`    AS `UPDATEUSER`,
       `roeee`.`ro_personaccount`.`UPDATETIME`    AS `UPDATETIME`
from `roeee`.`ro_personaccount`;

